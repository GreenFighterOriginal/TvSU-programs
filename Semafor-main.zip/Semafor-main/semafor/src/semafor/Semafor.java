package semafor;

import view.Controller;

public class Semafor {

    public static void main(String[] args) {
        Controller c = Controller.getIntance();
    }
}
