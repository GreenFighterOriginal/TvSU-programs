package programma;

public interface Command {
    public void apply();
}
